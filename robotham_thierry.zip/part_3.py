import pandas as pd
file_path = "C:\\Users\\thier\Downloads\\ds_salaries.csv"
data = pd.read_csv(file_path)
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
#Getting experience levels and dummies datas
x = data.experience_level
x = pd.get_dummies(data=x, drop_first = True)
y = data.salary_in_usd
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.2, random_state = 1)
re = LinearRegression()
re.fit(x_train, y_train)
y_pre = re.predict(x_test)
print(y_pre) ## creating a predicting the y-variable data with the model by using the x variable testing data
#printing outcome
print(re.score(x_test, y_test))

