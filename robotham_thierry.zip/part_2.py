import pandas as pd
file_path = "C:\\Users\\thier\\Downloads\\ds_salaries.csv"
data = pd.read_csv(file_path)
#Using the path in order to create plots on the graph.
import matplotlib.pyplot as plt
plt.boxplot(data.salary_in_usd)
plt.show()
#labelling all the plots x's and y's
x = data.job_title
y = data.salary_in_usd
plt.bar(x, y, color='red')
plt.xlabel('Job')
plt.ylabel('salary')
plt.show()
plt.hist(y, bins=30)
plt.xlabel('Salary')
plt.ylabel('Frequency')
#show all the plots that are labeled.
plt.show()
