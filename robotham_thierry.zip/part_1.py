import pandas as pd
filepath = "C:\\Users\thier\\Downloads\\ds_salaries.csv"
data = pd.read_csv(filepath)
#using the file for data informations
print(data.head())
print(data.shape)
print(data.job_title)
print(data['salary_in_usd'])
print(data.iloc[3:11, :])
print(data.salary_in_usd.describle())